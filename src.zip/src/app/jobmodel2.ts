export class Jobmodeltwo
{
   
    public jobtitle:string;

    constructor(jobtitle:string)
    {
        
        this.jobtitle=jobtitle;
       
    }

   
}