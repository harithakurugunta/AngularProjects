export class Jobmodel
{
    public designation_name : string;


    constructor(designation_name:string)
    {
        this.designation_name = designation_name
        
       
    }

   
}